local MyEmitter = nil
Particles.DeleteEmitter("E1")