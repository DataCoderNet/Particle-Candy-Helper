

    -----------------------
    --1.- START EMITTER
    -----------------------
    Particles.StartEmitter("E1")
    Particles.StartAutoUpdate()
    



